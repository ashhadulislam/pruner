import setuptools

setuptools.setup(
	name="torchpruner",
	version="0.0.1",
	author="Ashhadul Islam, Samir Brahim Belhaouari",
	description="pruning pytorch neural networks",
	packages=["torchpruner"]

	)